1)Start WanServer with us
2)Start WanServer with eu
3)Start WanClient with us
4)Start WanClient with eu

and if u start publishing from us client you can see eu client getting it