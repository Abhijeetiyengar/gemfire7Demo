package com.test.gemfire.examples.functions;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.execute.FunctionAdapter;
import com.gemstone.gemfire.cache.execute.FunctionContext;
import com.gemstone.gemfire.cache.execute.RegionFunctionContext;
import com.gemstone.gemfire.cache.partition.PartitionRegionHelper;
import com.test.gemfire.examples.indexes.EmployeeBean;

import java.util.Set;

/**
 * Created by abhijeetiyengar on 12/2/15.
 */
public class RegionLevelServiceFunction extends FunctionAdapter {
    @Override
    public void execute(FunctionContext functionContext) {

        RegionFunctionContext context = (RegionFunctionContext) functionContext;
        Set keys = context.getFilter();
        String arg=(String)context.getArguments();

        Cache cache=CacheFactory.getAnyInstance();

        Region parentRegion=cache.getRegion("replicatedRegion");


        Region<String,EmployeeBean> regionData=PartitionRegionHelper.getLocalDataForContext(context);

        for(EmployeeBean employeeBean:regionData.values())
        {
            employeeBean.setName(employeeBean.getName()+"_"+arg);
            parentRegion.put(employeeBean.getEmployeeId(),employeeBean);

        }


    }

    public boolean hasResult() {
        return false;
    }

    public boolean optimizeForWrite() {
        return true
                ;
    }

    @Override
    public String getId() {
        return "RegionLevelServiceFunction";
    }

    public boolean isHA() {
        return false;
    }
}
