package com.test.gemfire.examples.continiousQuery;

import com.gemstone.gemfire.cache.Operation;
import com.gemstone.gemfire.cache.query.CqEvent;
import com.gemstone.gemfire.cache.query.CqListener;
import com.test.gemfire.examples.indexes.EmployeeBean;

/**
 * Created by abhijeetiyengar on 12/2/15.
 */
public class CQListener implements CqListener {
    public void onEvent(CqEvent cqEvent) {

        Operation queryOperation = cqEvent.getQueryOperation();
        // key and new value from the event
        Object key = cqEvent.getKey();

        EmployeeBean employeeBean=(EmployeeBean)cqEvent.getNewValue();


        if(queryOperation.isUpdate())
        {
            System.out.println("Query Operation was update for "+key+" and new value is "+employeeBean);
        }
        if(queryOperation.isCreate())
        {
            System.out.println("Query Operation was create for "+key+" and new value is "+employeeBean);
        }
        if(queryOperation.isDestroy())
        {
            System.out.println("Query Operation was destroy for "+key+" and new value is "+employeeBean);
        }

    }

    public void onError(CqEvent cqEvent) {
        cqEvent.getThrowable().printStackTrace();
    }

    public void close() {

    }
}
