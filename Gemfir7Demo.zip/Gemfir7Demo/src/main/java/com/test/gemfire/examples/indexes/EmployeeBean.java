package com.test.gemfire.examples.indexes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by abhijeetiyengar on 11/30/15.
 */
public class EmployeeBean implements Serializable {

    private String name;

    private  String lastName;

    private AddressBean address;

    private String employeeId;



    private List<EmployeeBean> subordinateEmployees=new ArrayList<EmployeeBean>();

    public void addSubbordinate(EmployeeBean employeeBean)
    {
        subordinateEmployees.add(employeeBean);
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public AddressBean getAddress() {
        return address;
    }

    public void setAddress(AddressBean address) {
        this.address = address;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "EmployeeBean{" +
                "address=" + address +
                ", name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", subordinateEmployees=" + subordinateEmployees +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<EmployeeBean> getSubordinateEmployees() {
        return subordinateEmployees;
    }
}
