package com.test.gemfire.locator;

/**
 * Created by abhijeetiyengar on 11/11/15.
 */
public class StopLuxoLocator {

    public static void main(String args[])
    {

        String parameters[]={"stop-locator","-port=40402" ,"-dir=gemfire_tmp_dir","-Dgemfire.distributed-system-id=1","-Dgemfire.log-file=locator.log"};

        com.gemstone.gemfire.internal.SystemAdmin.main(parameters);
    }
}
