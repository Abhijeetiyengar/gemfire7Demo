package com.test.gemfire.examples.p2pCacheListnerPartioned;

import com.gemstone.gemfire.cache.CacheWriterException;
import com.gemstone.gemfire.cache.Declarable;
import com.gemstone.gemfire.cache.EntryEvent;
import com.gemstone.gemfire.cache.util.CacheWriterAdapter;

import java.util.Properties;

/**
 * Created by abhijeetiyengar on 12/5/15.
 */
public class P2PCacheWriter extends CacheWriterAdapter implements Declarable{


    public void beforeCreate(EntryEvent event) throws CacheWriterException {
        System.out.println("In the Create ");

    }

    public void beforeDestroy(EntryEvent event) throws CacheWriterException {
        System.out.println("In the destroy ");
    }

    public void beforeUpdate(EntryEvent event) throws CacheWriterException {
        System.out.println("In the update ");
    }

    public void init(Properties properties) {

    }
}
