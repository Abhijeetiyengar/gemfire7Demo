package com.test.gemfire.examples.pdxWithReadPDX;


import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.Region;
import com.test.gemfire.examples.customPersonalPartion.Customer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.gemfire.GemfireTemplate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 11/11/15.
 */
public class StartClient {

    public  static void main (String args[]) throws Exception
    {
        ApplicationContext application=new ClassPathXmlApplicationContext("simpleClientExample/application-context_without_cahce1-client.xml");

        Cache testCache=(Cache)application.getBean("gemfire-cache");

        Region region=testCache.getRegion("replicatedRegion");

        GemfireTemplate template=new GemfireTemplate(region);

        System.out.println("Check if other server is started too and if yes press enter , if strated press I for inster , C for check " +
                " and e for exit");

        BufferedReader is=new BufferedReader(new InputStreamReader(System.in));

        String name=is.readLine();
        int customerId=1;
        while(!(name).equals("E"))
        {
            if (name.equals("I"))
            {

                    System.out.println("Enter Id");

                    is=new BufferedReader(new InputStreamReader(System.in));

                    name=is.readLine();
                    Customer customer=new Customer();
                    customer.setCustomerId(name);
                    customer.setCustomerName("Customer "+name);
                    template.put(name,customer);
            }
            else if(name.equals("C"))
            {

                Set<Map.Entry<String, Customer>>  localdataSet = region.entrySet();
                System.out.println("--Local Data --");
                for(Map.Entry<String, Customer> entry: localdataSet){
                    System.out.println(entry.getKey() + "        " + entry.getValue());
                }

            }
            else if(name.equals("G"))
            {

                System.out.println("Enter Id");

                is=new BufferedReader(new InputStreamReader(System.in));

                name=is.readLine();
                Customer c=template.get(name);
                System.out.println(c.getCustomerId()+"--"+c.getCustomerName());



            }

            else if(name.equals("E"))
            {
                System.exit(0);
            }
            System.out.println("Use one of I , C ,G or E");
            is=new BufferedReader(new InputStreamReader(System.in));

            name=is.readLine();

        }






    }

}
