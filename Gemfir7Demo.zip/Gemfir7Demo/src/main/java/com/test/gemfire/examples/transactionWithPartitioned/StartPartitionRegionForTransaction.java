package com.test.gemfire.examples.transactionWithPartitioned;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;
import com.gemstone.gemfire.cache.CacheTransactionManager;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.partition.PartitionRegionHelper;
import com.gemstone.gemfire.cache.query.Query;
import com.gemstone.gemfire.cache.query.QueryService;
import com.gemstone.gemfire.cache.query.SelectResults;
import com.test.gemfire.examples.customPersonalPartion.Customer;
import com.test.gemfire.examples.indexes.AddressBean;
import com.test.gemfire.examples.indexes.EmployeeBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.gemfire.GemfireTemplate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 11/16/15.
 */
public class StartPartitionRegionForTransaction {

    public static void main(String args[]) throws  Exception
    {

        System.out.println("Please enter Server port");

        BufferedReader is=new BufferedReader(new InputStreamReader(System.in));

        String severPort=new String(is.readLine());

        System.out.println("Please enter Server name");

        is=new BufferedReader(new InputStreamReader(System.in));

        String serverName=new String(is.readLine());

        System.setProperty("gemfire.name",serverName);

        System.setProperty("gemfire.port",severPort);

        ApplicationContext application=new ClassPathXmlApplicationContext("transactionWithPartitioned/application-context.xml");

        Cache testCache=(Cache)application.getBean("gemfire-cache");

        Region region=testCache.getRegion("partitionRegion");

        GemfireTemplate template=new GemfireTemplate(region);

        String queryString="select * from /partitionRegion ";



        System.out.println("Use one of I , C  ,G or E");


        is=new BufferedReader(new InputStreamReader(System.in));

        String inputValue=is.readLine();
        int customerId=1;
        while(!(inputValue).equals("E"))
        {
            if (inputValue.equals("I"))
            {

                System.out.println("Enter Id");

                is=new BufferedReader(new InputStreamReader(System.in));

                inputValue=is.readLine();

                EmployeeBean e=new EmployeeBean();
                e.setEmployeeId(inputValue);
                e.setName("FirstName "+inputValue);
                e.setLastName("LastName 1 "+inputValue);
                AddressBean addressBean=new AddressBean();
                addressBean.setFirstLine("FirstLine "+inputValue);
                addressBean.setSecondLine("SecondLine "+inputValue);
                addressBean.setPinCode(56000);
                e.setAddress(addressBean);
                template.put(inputValue,e);
            }

            else if(inputValue.equals("C"))
            {
                Region localData = PartitionRegionHelper.getLocalData(region);
                Set<Map.Entry<String, Customer>> localdataSet = localData.entrySet();
                System.out.println("--Local Data --");
                for(Map.Entry<String, Customer> entry: localdataSet){
                    System.out.println(entry.getKey() + "        " + entry.getValue());
                }

            }

            else if(inputValue.equals("U"))
            {
                /*System.out.println("For Id");

                is=new BufferedReader(new InputStreamReader(System.in));

                inputValue=is.readLine();*/

                System.out.println("Modified last name");

                is=new BufferedReader(new InputStreamReader(System.in));

                String newlastName=is.readLine();

                QueryService qs=testCache.getQueryService();
                Query query=qs.newQuery(queryString);

                Object[] params = new Object[1];
                //params[0] =inputValue ;

                SelectResults results = (SelectResults)query.execute();

                CacheTransactionManager mgr = CacheFactory.getAnyInstance().getCacheTransactionManager();

                mgr.begin();

                int numberOfResults=results.size();

                Iterator it=results.iterator();

                while (it.hasNext())
                {
                    EmployeeBean employee=(EmployeeBean)it.next();

                    employee.setLastName(newlastName);

                    region.put(employee.getEmployeeId(),employee);

                }

                mgr.commit();


            }

            else if(inputValue.equals("G"))
            {

                System.out.println("Enter Id");

                is=new BufferedReader(new InputStreamReader(System.in));

                inputValue=is.readLine();
                EmployeeBean c=template.get(inputValue);
                if(c!=null)
                     System.out.println(c.toString());
                else
                    System.out.println("No Bean found");

            }

            else if(inputValue.equals("E"))
            {
                System.exit(0);
            }
            System.out.println("Use one of I , C ,G or E");
            is=new BufferedReader(new InputStreamReader(System.in));

            inputValue=is.readLine();

        }

    }
}
