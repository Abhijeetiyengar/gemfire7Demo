package com.test.gemfire.examples.functions;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.RegionService;
import com.gemstone.gemfire.cache.client.ClientCacheFactory;
import com.gemstone.gemfire.cache.execute.FunctionService;
import com.gemstone.gemfire.cache.execute.ResultCollector;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Properties;

/**
 * Created by abhijeetiyengar on 11/16/15.
 */
public class StartClientWithCache1ForFunction {

    public static void main(String args[]) throws  Exception
    {
        ApplicationContext application=new ClassPathXmlApplicationContext("function/application-context.xml");

        Cache testCache=(Cache)application.getBean("gemfire-cache");

        Properties prop=new Properties();
        prop.put("ssl-protocols","any");

        RegionService regionService= ClientCacheFactory.getAnyInstance().createAuthenticatedView(prop,"serverPool");

        ResultCollector collector=FunctionService.onServer(regionService).execute("SimpleFunctionOnServer");

        System.out.println(collector);



    }
}
