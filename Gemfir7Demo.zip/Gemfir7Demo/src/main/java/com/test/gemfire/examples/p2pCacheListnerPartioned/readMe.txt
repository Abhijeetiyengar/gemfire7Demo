1) Start 2 server with 2 40404 and 40406

    intilially interest-policy is all , so both will recieve update on listner

    change interest policy to cache-content and you can see only respecitve cache listner is called

    Cache writer doesnt depend on it