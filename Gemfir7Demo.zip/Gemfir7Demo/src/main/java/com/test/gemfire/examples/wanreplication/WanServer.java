package com.test.gemfire.examples.wanreplication;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by abhijeetiyengar on 12/9/15.
 */
public class WanServer {

    public static void main(String args[]) throws  Exception
    {

        System.out.println("Please enter hub name , us or eu");

        BufferedReader is=new BufferedReader(new InputStreamReader(System.in));

        String hubName=new String(is.readLine());

        Cache cache=new CacheFactory().set("cache-xml-file", "wanreplication/" + hubName + "hub-cache.xml").create();



    }
}
