package com.test.gemfire.server;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by abhijeetiyengar on 11/11/15.
 */
public class StartLuxorServer {

    public  static void main (String args[])
    {
        ApplicationContext application=new ClassPathXmlApplicationContext("application-context.xml");
    }

}
