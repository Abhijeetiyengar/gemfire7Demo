package com.test.gemfire.examples.functions;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.execute.FunctionAdapter;
import com.gemstone.gemfire.cache.execute.FunctionContext;
import com.gemstone.gemfire.cache.execute.RegionFunctionContext;
import com.gemstone.gemfire.cache.partition.PartitionRegionHelper;
import com.test.gemfire.examples.customPersonalPartion.Customer;
import com.test.gemfire.examples.indexes.EmployeeBean;

import java.util.Map;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 12/2/15.
 */
public class RegionLevelServiceHAFunction extends FunctionAdapter {
    @Override
    public void execute(FunctionContext functionContext) {

        RegionFunctionContext context = (RegionFunctionContext) functionContext;
        Set keys = context.getFilter();
        String arg=(String)context.getArguments();

        Cache cache=CacheFactory.getAnyInstance();

        Region parentRegion=cache.getRegion("replicatedRegion");


        Set<Map.Entry<Object, Object>>  localdataSet=PartitionRegionHelper.getLocalData(parentRegion).entrySet();




        if(localdataSet.size()>0)
        {
            for(Map.Entry entry: localdataSet){
                if(entry.getKey().equals("4"))
                    functionContext.getResultSender().lastResult(entry.getValue());
            }
        }
        functionContext.getResultSender().lastResult("Not Found");




    }

    public boolean hasResult() {
        return true;
    }

    public boolean optimizeForWrite() {
        return false
                ;
    }

    @Override
    public String getId() {
        return "RegionLevelServiceFunction";
    }

    public boolean isHA() {
        return true;
    }
}
