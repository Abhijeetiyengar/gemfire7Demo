Start server at 40404 and 40406

and then U for last name

it will fail to show case that transcation can only work withing same partition