package com.test.gemfire.examples.continiousQuery;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.client.ClientCacheFactory;
import com.gemstone.gemfire.cache.execute.Execution;
import com.gemstone.gemfire.cache.execute.FunctionService;
import com.gemstone.gemfire.cache.query.*;
import com.test.gemfire.examples.functions.RegionLevelServiceFunction;
import com.test.gemfire.examples.partitionedRegionQuerying.Client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 12/2/15.
 */
public class NonDurableContiniousQueryClient {


    public static void main(String args[]) throws RuntimeException {

        ApplicationContext application = new ClassPathXmlApplicationContext("continiousQuery/application-context.xml");

        CqAttributesFactory cqf = new CqAttributesFactory();

        CQListener listener = new CQListener();
        CqListener[] cqListeners = {listener };
        cqf.initCqListeners(cqListeners);
        CqAttributes cqa = cqf.create();

        String queryStr = "SELECT * FROM /replicatedRegion t where t.lastName like '%4%'";

        QueryService queryService = ClientCacheFactory.getAnyInstance().getQueryService("serverPool");



        try {
            CqQuery employeeCQ = queryService.newCq("employeeCQ", queryStr, cqa);
            SelectResults sResults = employeeCQ.executeWithInitialResults();

            List list1 = sResults.asList();
            for (int i = 0; i < list1.size(); i++) {
                System.out.println(list1.get(i));


            }



        } catch (CqExistsException e) {
            e.printStackTrace();
        } catch (CqException e) {
            e.printStackTrace();
        } catch (RegionNotFoundException e) {
            e.printStackTrace();
        }

        for(;;)
        {
            try {
                Thread.sleep(6000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }



}
