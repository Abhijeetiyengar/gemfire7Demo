package com.test.gemfire.examples.simpleDelta;

import com.gemstone.gemfire.Delta;
import com.gemstone.gemfire.InvalidDeltaException;
import com.gemstone.gemfire.cache.Declarable;
import com.gemstone.gemfire.internal.SystemAdmin;

import java.io.*;
import java.util.Properties;

/**
 * Created by abhijeetiyengar on 11/16/15.
 */
public class SampleDeltaBean implements Externalizable,Delta,Declarable {

    private String key;
    private String value1;

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        isValue2Changed=true;
        this.value2 = value2;
    }

    private String value2;

    boolean isValue2Changed=false;
    boolean isValue1Changed=false;

    public String getValue1() {

        return value1;
    }

    public void setValue1(String value1) {
        isValue1Changed=true;
        this.value1 = value1;
    }

    public String getKey() {

        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "SampleDeltaBean{" +
                "key='" + key + '\'' +
                ", value1='" + value1 + '\'' +
                ", value2='" + value2 + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SampleDeltaBean)) return false;

        SampleDeltaBean that = (SampleDeltaBean) o;

        if (getKey() != null ? !getKey().equals(that.getKey()) : that.getKey() != null) return false;
        else return true;

    }

    @Override
    public int hashCode() {
        int result = getKey() != null ? getKey().hashCode() : 0;

        return result;
    }

    public boolean hasDelta() {
        return true;
    }



    public void toDelta(DataOutput dataOutput) throws IOException {
        if(isValue1Changed==true)
        {
            System.out.println("Modifying value 1");
            dataOutput.writeUTF("value1");
            dataOutput.writeUTF(value1);
            isValue1Changed=false;
        }
        if(isValue2Changed==true)
        {

            System.out.println("Modifying Value 2");
            dataOutput.writeUTF("value2");
            dataOutput.writeUTF(value2);
            isValue1Changed=false;
        }
        System.out.println("In to delta");

    }

    public void fromDelta(DataInput dataInput) throws IOException, InvalidDeltaException {
        if(dataInput==null  )
            return;
        System.out.println("In from delta "+dataInput);

        String modifiedParam=dataInput.readUTF();
        String modifiedValue=dataInput.readUTF();


        if(modifiedParam.equals("value1"))
        {
            System.out.println("Modified Value1");
            this.value1=modifiedValue;
        }
        if(modifiedParam.equals("value2"))
        {
            System.out.println("Modified Value2");
            this.value2=modifiedValue;
        }

    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(key);
        out.writeObject(value1);
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        key=(String)in.readObject();
        value1 =(String)in.readObject();

    }

    public void init(Properties properties) {

    }
}
