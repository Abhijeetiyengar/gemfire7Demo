package com.test.gemfire.locator;

/**
 * Created by abhijeetiyengar on 11/11/15.
 */
public class StartLocator {

    public static void main(String args[])
    {

        String parameters[]={"start-locator","-Dname=locator1","-port=40402" ,"-dir=gemfire_tmp_dir","-Dgemfire.distributed-system-id=1","-Dgemfire.jmx-manager-http-port=8081","-Dgemfire.log-file=locator.log"};
        System.out.println("Starting");
        com.gemstone.gemfire.internal.SystemAdmin.main(parameters);
        System.out.println("Started");
    }
}
