1) Start server at 40404 and 40406

and then U for last name

it will fail to show case that transcation will work fine

2) Now start both server in debug mode

Start Transaction on one of them and F6 it till while loop of results .

The Start Transaction on another Server and run it through. Then do C option on it and you see its hung as its waiting for ack

and then let the first one complete and it will throw and exception

3) Change scope tp no-ack

 Now start both server in debug mode

  Start Transaction on one of them and F6 it till while loop of results .

  The Start Transaction on another Server and run it through . Now you do C option , it doesnt hang , and you can see new value

  and then let the first one complete and it will throw and exception and you see the new value is overwritten from the value of above line