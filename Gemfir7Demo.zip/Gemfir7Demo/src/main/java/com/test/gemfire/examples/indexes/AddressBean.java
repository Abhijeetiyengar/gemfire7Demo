package com.test.gemfire.examples.indexes;

import java.io.Serializable;

/**
 * Created by abhijeetiyengar on 11/30/15.
 */
public class AddressBean implements Serializable {

    private String firstLine;

    public String getSecondLine() {
        return secondLine;
    }

    public void setSecondLine(String secondLine) {
        this.secondLine = secondLine;
    }

    public long getPinCode() {
        return pinCode;
    }

    public void setPinCode(long pinCode) {
        this.pinCode = pinCode;
    }

    public String getFirstLine() {
        return firstLine;
    }

    public void setFirstLine(String firstLine) {
        this.firstLine = firstLine;
    }

    private String secondLine;
    private long pinCode;

    @Override
    public String toString() {
        return "AddressBean{" +
                "firstLine='" + firstLine + '\'' +
                ", secondLine='" + secondLine + '\'' +
                ", pinCode=" + pinCode +
                '}';
    }
}
