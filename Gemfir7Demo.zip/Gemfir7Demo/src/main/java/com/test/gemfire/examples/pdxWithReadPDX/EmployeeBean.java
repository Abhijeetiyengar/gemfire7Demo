package com.test.gemfire.examples.pdxWithReadPDX;

import com.gemstone.gemfire.pdx.PdxReader;
import com.gemstone.gemfire.pdx.PdxSerializable;
import com.gemstone.gemfire.pdx.PdxWriter;

/**
 * Created by abhijeetiyengar on 11/16/15.
 */
public class EmployeeBean implements PdxSerializable {

    private String employedId;
    private String employeeName;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmployeeBean)) return false;

        EmployeeBean that = (EmployeeBean) o;

        return !(getEmployedId() != null ? !getEmployedId().equals(that.getEmployedId()) : that.getEmployedId() != null);

    }

    @Override
    public int hashCode() {
        return getEmployedId() != null ? getEmployedId().hashCode() : 0;
    }

    public String getAddress() {
        return address;

    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployedId() {
        return employedId;
    }

    public void setEmployedId(String employedId) {
        this.employedId = employedId;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    private String address;

    public void toData(PdxWriter pdxWriter) {

    }

    public void fromData(PdxReader pdxReader) {

    }
}
