package com.test.gemfire.examples.wanreplication;

import com.gemstone.gemfire.CancelException;
import com.gemstone.gemfire.SystemFailure;
import com.gemstone.gemfire.cache.CacheException;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.client.ClientCache;
import com.gemstone.gemfire.cache.client.ClientCacheFactory;
import com.gemstone.gemfire.internal.cache.LocalRegion;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

/**
 * Created by abhijeetiyengar on 12/9/15.
 */
public class WanClient {

    protected ClientCache cache;

    /** The GemFire <code>Region</code> */
    protected Region<String, String> region;

    public static void main(String args[]) throws  Exception
    {
        System.out.println("Please enter hub name , us or eu");

        BufferedReader is=new BufferedReader(new InputStreamReader(System.in));

        String hubName=new String(is.readLine());

        ClientCache cache=new ClientCacheFactory().set("cache-xml-file", "wanreplication/" + hubName + "hub-clientcache.xml").create();

        WanClient client=new WanClient();
        client.cache=cache;

        client.initializeRegion("/trades");



        // Execute test
        if (hubName.equals("us")) {
            // Do puts

            System.out.println("wait for eu client to join");

             is=new BufferedReader(new InputStreamReader(System.in));

            hubName=new String(is.readLine());

            client.doPuts();
        } else if (hubName.equals("eu")) {
            // Register interest in all keys and wait for updates
            client.registerInterest();
            client.waitForever();
        } else {
            usage();
        }

    }

    protected static void usage() {
        System.err.println("\n** Missing site name\n");
        System.err.println("usage: java wan.WANClient <site>");
        System.err.println("  site   The name of the WAN site (either 'us' or 'eu')");
        System.exit(1);
    }

    protected void registerInterest() throws CacheException
    {
        LocalRegion lr = (LocalRegion) this.region;
        lr.registerInterest("ALL_KEYS");
        System.out.println("Registered interest in " + lr.getInterestList() + " for region " + lr.getName());
    }

    /**
     * Waits forever.
     */
    protected void waitForever() throws InterruptedException {
        Object obj = new Object();
        if (Thread.interrupted()) throw new InterruptedException();
        synchronized (obj) {
            obj.wait();
        }
    }

    protected void initializeRegion(String regionName) {
        this.region = this.cache.getRegion(regionName);
        System.out.println("Retrieved region: " + this.region);
    }

    protected void doPuts() {
        // Spawn several threads to execute
        for (int i=0; i<10; i++) {
            Thread thread = new Thread(
                    new Runnable() {
                        public void run() {
                            Random random = new Random();
                            while (true) {
                                SystemFailure.checkFailure(); // GemStoneAddition
                                try {
                                    // Put a random entry into the region
                                    int j = random.nextInt(5000);
                                    String key = "key-" + j;
                                    String value = String.valueOf(j);
                                    System.out.println(Thread.currentThread().getName() + ": Putting " + key + "->" + value);
                                    try {
                                        WanClient.this.region.put(key, value);
                                    }
                                    catch (CancelException cce) {
                                        System.exit(0);
                                    }
                                    Thread.sleep(10);
                                }
                                catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });
            thread.start();
        }
    }
}
