package com.test.gemfire.examples.functions;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;
import com.gemstone.gemfire.cache.Declarable;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.execute.FunctionAdapter;
import com.gemstone.gemfire.cache.execute.FunctionContext;
import com.gemstone.gemfire.distributed.DistributedSystem;
import com.test.gemfire.examples.customPersonalPartion.Customer;
import com.test.gemfire.examples.indexes.EmployeeBean;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 12/1/15.
 */
public class SimpleFunctionOnServer extends FunctionAdapter implements Declarable {


    @Override
    public void execute(FunctionContext functionContext) {

        System.out.println("Hi I am in function");

        Cache cache=CacheFactory.getAnyInstance();

        Region region=cache.getRegion("replicatedRegion");


        Set<Map.Entry<String, Customer>> localdataSet = region.entrySet();
        System.out.println("--Local Data --");
        for(Map.Entry<String, Customer> entry: localdataSet){
            functionContext.getResultSender().sendResult(entry.getValue());
        }
        //throw new RuntimeException();
       functionContext.getResultSender().lastResult("done");

    }

    @Override
    public String getId() {
        return "SimpleFunctionOnServer";
    }

    public void init(Properties properties) {

    }
}
