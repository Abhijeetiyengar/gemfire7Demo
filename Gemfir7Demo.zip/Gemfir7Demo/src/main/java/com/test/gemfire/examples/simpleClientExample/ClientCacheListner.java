package com.test.gemfire.examples.simpleClientExample;

import com.gemstone.gemfire.cache.EntryEvent;
import com.gemstone.gemfire.cache.util.CacheListenerAdapter;

/**
 * Created by abhijeetiyengar on 11/15/15.
 */
public class ClientCacheListner extends CacheListenerAdapter {

    @Override
    public void afterCreate(EntryEvent event) {
        System.out.println("HI i am in event");
        System.out.println(event.getKey() +" --" + event.getNewValue()+"--"+event.getOldValue());
    }

}
