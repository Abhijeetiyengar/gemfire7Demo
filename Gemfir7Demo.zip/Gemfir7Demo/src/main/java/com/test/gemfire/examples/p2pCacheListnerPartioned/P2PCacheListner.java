package com.test.gemfire.examples.p2pCacheListnerPartioned;

import com.gemstone.gemfire.cache.Declarable;
import com.gemstone.gemfire.cache.EntryEvent;
import com.gemstone.gemfire.cache.util.CacheListenerAdapter;

import java.util.Properties;

/**
 * Created by abhijeetiyengar on 12/5/15.
 */
public class P2PCacheListner extends CacheListenerAdapter implements Declarable {

    public void afterCreate(EntryEvent event) {
        System.out.println("Hi I am here in afterCreate  for "+event.getKey());


    }

    @Override
    public void afterDestroy(EntryEvent event) {
        System.out.println("Hi I am here in after destroy for "+event.getKey());

    }

    @Override
    public void afterUpdate(EntryEvent event) {
        System.out.println("Hi I am here in after Update for "+event.getKey());

    }

    public void init(Properties properties) {
       System.out.println("Dummy Param is " + properties.get("dummyParam") );
    }
}
