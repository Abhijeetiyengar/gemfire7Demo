package com.test.gemfire.examples.functions;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.client.ClientCacheFactory;
import com.gemstone.gemfire.cache.client.PoolManager;
import com.gemstone.gemfire.cache.execute.Execution;
import com.gemstone.gemfire.cache.execute.FunctionService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by abhijeetiyengar on 12/2/15.
 */
public class RegionLevelServiceFunctionClient {


  public static void main(String args[])
  {

      ApplicationContext application=new ClassPathXmlApplicationContext("function/regionfunction-application-context.xml");

      Cache testCache=(Cache)application.getBean("gemfire-cache");

      RegionLevelServiceFunction regionLevelServiceFunction=new RegionLevelServiceFunction();
      FunctionService.registerFunction(regionLevelServiceFunction);

      Set keysForGet = new HashSet<String>();
      keysForGet.add("4");

      Region replicatedRegion=ClientCacheFactory.getAnyInstance().getRegion("replicatedRegion");

      replicatedRegion.get("4");


      Execution execution = FunctionService.onRegion(replicatedRegion)
              .withFilter(keysForGet)
              .withArgs("_dummy");

      execution.execute(regionLevelServiceFunction);

  }





}
